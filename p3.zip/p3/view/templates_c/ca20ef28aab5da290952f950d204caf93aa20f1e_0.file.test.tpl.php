<?php
/* Smarty version 4.3.4, created on 2024-02-15 04:18:38
  from 'C:\xampp\htdocs\progra3\semana5\view\templates\test.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_65cd828ee41088_98177206',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ca20ef28aab5da290952f950d204caf93aa20f1e' => 
    array (
      0 => 'C:\\xampp\\htdocs\\progra3\\semana5\\view\\templates\\test.tpl',
      1 => 1707967053,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65cd828ee41088_98177206 (Smarty_Internal_Template $_smarty_tpl) {
?><!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $_smarty_tpl->tpl_vars['titulo']->value;?>
</title>
</head>
<body>
    <h1>Esto es una prueba del framework <?php echo $_smarty_tpl->tpl_vars['msg']->value;?>
</h1>
</body>
</html><?php }
}
