<?php
/* Smarty version 4.3.4, created on 2024-02-18 02:47:05
  from 'C:\xampp\htdocs\progra3\proyecto_final\css\style.css' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_65d16199edb020_09474033',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'ba5e5d9e86a97a8227e840b3344de8df2b27b324' => 
    array (
      0 => 'C:\\xampp\\htdocs\\progra3\\proyecto_final\\css\\style.css',
      1 => 1708220820,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65d16199edb020_09474033 (Smarty_Internal_Template $_smarty_tpl) {
?>html, body {
    height: 100%;
}

<?php }
}
