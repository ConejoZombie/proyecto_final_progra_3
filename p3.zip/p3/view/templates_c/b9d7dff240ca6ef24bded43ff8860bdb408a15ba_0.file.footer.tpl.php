<?php
/* Smarty version 4.3.4, created on 2024-02-18 02:58:04
  from 'C:\xampp\htdocs\progra3\proyecto_final\view\templates\footer.tpl' */

/* @var Smarty_Internal_Template $_smarty_tpl */
if ($_smarty_tpl->_decodeProperties($_smarty_tpl, array (
  'version' => '4.3.4',
  'unifunc' => 'content_65d1642c3ee659_03360105',
  'has_nocache_code' => false,
  'file_dependency' => 
  array (
    'b9d7dff240ca6ef24bded43ff8860bdb408a15ba' => 
    array (
      0 => 'C:\\xampp\\htdocs\\progra3\\proyecto_final\\view\\templates\\footer.tpl',
      1 => 1708221447,
      2 => 'file',
    ),
  ),
  'includes' => 
  array (
  ),
),false)) {
function content_65d1642c3ee659_03360105 (Smarty_Internal_Template $_smarty_tpl) {
?>

<div class="container text-center">
  <div class="row">
    <div class="col">
      Column
    </div>
    <div class="col">
      Column
    </div>
    <div class="col">
      Column
    </div>
  </div>
</div><?php }
}
